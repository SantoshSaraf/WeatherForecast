package com.weather.api;

import com.weather.WeatherForecastApplication;
import com.weather.model.AverageStats;
import lombok.extern.slf4j.Slf4j;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.http.*;
import org.springframework.test.context.junit4.SpringRunner;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;

@Slf4j
@RunWith(SpringRunner.class)
@SpringBootTest(classes = WeatherForecastApplication.class,webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class WeatherMetricsTest {

    @LocalServerPort
    private int port;

    TestRestTemplate restTemplate = new TestRestTemplate();

    @Test
    public void testWeatherMetricCalculator(){
        log.info("Registered local port :: "+port);
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        HttpEntity request = new HttpEntity<>(headers);
        ResponseEntity<AverageStats> response = restTemplate.exchange(createLocalTestUrl("weather/api/data?city=London"), HttpMethod.GET,request,AverageStats.class);
        Assert.assertEquals(HttpStatus.OK,response.getStatusCode());
    }

    private String createLocalTestUrl(String URI){
        return "http://localhost:"+port+URI;
    }
}
