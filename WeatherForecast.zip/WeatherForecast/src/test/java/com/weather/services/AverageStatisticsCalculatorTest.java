package com.weather.services;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.weather.model.AverageStats;
import com.weather.model.ForecastDetail;
import com.weather.model.OpenWeatherData;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import java.io.File;
import java.io.IOException;
import java.time.format.DateTimeFormatter;
import java.util.List;

@RunWith(MockitoJUnitRunner.class)
public class AverageStatisticsCalculatorTest {

    @InjectMocks
    AverageStatisticsCalculator averageStatisticsCalculator;
    @Mock
    AverageStatisticsService averageStatisticsService;

    ObjectMapper mapper = new ObjectMapper();

    @Test
    public void testCalculator() throws IOException{
        File file = new File("src/test/resources/OpenWeatherData.json");
        OpenWeatherData openWeatherData = mapper.readValue(file,OpenWeatherData.class);
        List<ForecastDetail> forecastDetails = openWeatherData.getList();
        AverageStats averageStats = averageStatisticsCalculator.averageStatisticsCalculator(forecastDetails,new AverageStats());
        Assert.assertEquals("2019-01-06 12:00:00",averageStats.getStartDateTime().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")));
        Assert.assertEquals("2019-01-09 06:00:00",averageStats.getEndDateTime().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")));
    }
}
