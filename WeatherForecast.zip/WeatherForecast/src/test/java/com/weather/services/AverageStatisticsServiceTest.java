package com.weather.services;

import com.weather.model.AverageStats;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.ArrayList;
import java.util.List;

@RunWith(SpringJUnit4ClassRunner.class)
public class AverageStatisticsServiceTest {

    AverageStatisticsServiceImpl averageStatisticsService = new AverageStatisticsServiceImpl();

    @Test
    public void testCalculateAverageDaily(){
        List<Double> dailyTemps = new ArrayList<>();
        dailyTemps.add(12.12);
        dailyTemps.add(10.12);
        dailyTemps.add(11.22);
        AverageStats averageStats = averageStatisticsService.calculateAverageDaily(dailyTemps,new AverageStats());
        Assert.assertEquals(11.15,averageStats.getDailyAverage().getValue(),0);
    }

    @Test
    public void testCalculateAverageNightly(){
        List<Double> nightlyTemps = new ArrayList<>();
        nightlyTemps.add(12.12);
        nightlyTemps.add(10.12);
        nightlyTemps.add(11.22);
        AverageStats averageStats = averageStatisticsService.calculateAverageNightly(nightlyTemps,new AverageStats());
        Assert.assertEquals(11.15,averageStats.getNightlyAverage().getValue(),0);
    }

    @Test
    public void testCalculateAveragePressure(){
        List<Double> pressureData = new ArrayList<>();
        pressureData.add(12.12);
        pressureData.add(10.12);
        pressureData.add(11.22);
        AverageStats averageStats = averageStatisticsService.calculateAveragePressure(pressureData,new AverageStats());
        Assert.assertEquals(11.15,averageStats.getPressureAverage().getValue(),0);
    }

}
