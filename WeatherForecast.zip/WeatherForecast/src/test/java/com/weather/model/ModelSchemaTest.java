package com.weather.model;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.junit4.SpringRunner;

import java.io.File;
import java.io.IOException;
import java.time.format.DateTimeFormatter;

@RunWith(SpringJUnit4ClassRunner.class)
public class ModelSchemaTest {

    ObjectMapper mapper = new ObjectMapper();

    @Test
    public void testTemperatureModel() throws IOException{
        File file = new File("src/test/resources/TemperatureDetail.json");
        TemperatureDetail temperatureDetail = mapper.readValue(file,TemperatureDetail.class);
        Assert.assertEquals(-4.05, (double) temperatureDetail.getTemp_min(),.00);
    }

    @Test
    public void testWeatherModel() throws IOException{
        File file = new File("src/test/resources/WeatherDetail.json");
        WeatherDetail weatherDetail = mapper.readValue(file,WeatherDetail.class);
        Assert.assertEquals("clear sky", (weatherDetail.getDescription()));
    }

    @Test
    public void testForecastDetail() throws IOException{
        File file = new File("src/test/resources/ForecastDetail.json");
        ForecastDetail forecastDetail = mapper.readValue(file,ForecastDetail.class);
        Assert.assertEquals("2019-01-07 06:00:00", forecastDetail.getDt_txt().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")));
    }

    @Test
    public void testOpenWeatherDataModel() throws IOException{
        File file = new File("src/test/resources/OpenWeatherData.json");
        OpenWeatherData openWeatherData = mapper.readValue(file,OpenWeatherData.class);
        Assert.assertEquals("London", openWeatherData.getCity().getName());
    }

}
