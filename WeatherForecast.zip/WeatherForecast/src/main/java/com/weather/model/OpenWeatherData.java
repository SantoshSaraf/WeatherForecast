package com.weather.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
@NoArgsConstructor
public class OpenWeatherData {

    private Integer cod;
    private Double message;
    private Integer cnt;
    private List<ForecastDetail> list;
    private City city;

}
