package com.weather.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class TemperatureDetail {
    private Double temp;
    private Double temp_max;
    private Double temp_min;
    private Double pressure;
    private Double sea_level;
    private Double grnd_level;
    private Integer humidity;
    private Double temp_kf;
}
