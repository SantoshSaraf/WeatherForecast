package com.weather.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class City {

    private Integer id;
    private String name;
    @JsonProperty("coord")
    private Coordinate coordinate;
    private String country;
    private Long population;
}
