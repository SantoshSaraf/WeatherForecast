package com.weather.exception;

import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

@Slf4j
@ControllerAdvice
public class ForecastExceptionHandler extends ResponseEntityExceptionHandler {

   @ExceptionHandler(OpenWeatherMapException.class)
   public ResponseEntity handleApiException(OpenWeatherMapException e){
       log.error("Exception occured when communicating with OpenWeatherMap api  - {}",e.getMessage());
       return new ResponseEntity(e.getMessage(),e.getStatus());
   }

}
