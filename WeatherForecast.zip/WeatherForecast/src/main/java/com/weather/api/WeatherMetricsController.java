package com.weather.api;

import com.weather.model.AverageStats;
import com.weather.model.ForecastDetail;
import com.weather.services.AverageStatisticsCalculator;
import com.weather.services.OpenWeatherMapService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.constraints.NotNull;
import java.util.List;

@RestController
@RequestMapping("/api")
public class WeatherMetricsController {

    @Autowired
    OpenWeatherMapService openWeatherMapService;
    @Autowired
    AverageStatisticsCalculator averageStatisticsCalculator;

    @GetMapping(value = "/data",produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<AverageStats> getAverageStats(@NotNull @RequestParam String city) throws Exception{
        List<ForecastDetail> forecastDetails = openWeatherMapService.getOpenWeatherForecastData(city);
        AverageStats averageStats = averageStatisticsCalculator.averageStatisticsCalculator(forecastDetails, new AverageStats());
        return new ResponseEntity<AverageStats>(averageStats,HttpStatus.OK);
    }

}
