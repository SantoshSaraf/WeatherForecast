package com.weather.config;

import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Configuration
@ConfigurationProperties(prefix="openweathermap")
@Getter
@Setter
public class OpenWeatherMapConfig {
    private String appId;
    private String forecastUrl;
    private String units;
}
