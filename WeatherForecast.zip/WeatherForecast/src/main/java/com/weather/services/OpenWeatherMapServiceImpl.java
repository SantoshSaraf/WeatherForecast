package com.weather.services;

import com.weather.config.OpenWeatherMapConfig;
import com.weather.exception.OpenWeatherMapException;
import com.weather.model.ForecastDetail;
import com.weather.model.OpenWeatherData;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestTemplate;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class OpenWeatherMapServiceImpl implements OpenWeatherMapService {

    @Autowired
    RestTemplate restTemplate;
    @Autowired
    OpenWeatherMapConfig openWeatherMapConfig;

    @Override
    public List<ForecastDetail> getOpenWeatherForecastData(String city) throws OpenWeatherMapException{
        Map<String,String> uriParams = getUriParams(city);
        try{
            ResponseEntity<OpenWeatherData> response = restTemplate.exchange(openWeatherMapConfig.getForecastUrl(),HttpMethod.GET,null,OpenWeatherData.class,uriParams);
            return response.getBody().getList();
        }catch(HttpStatusCodeException e){
            throw new OpenWeatherMapException(e.getStatusCode(),e.getResponseBodyAsString());
        }
    }

    @Override
    public Map<String,String> getUriParams(String city) {
        Map<String,String> uriMap = new HashMap<>();
        uriMap.put("city",city);
        uriMap.put("units",openWeatherMapConfig.getUnits());
        uriMap.put("APPID",openWeatherMapConfig.getAppId());
        return uriMap;
    }

}
