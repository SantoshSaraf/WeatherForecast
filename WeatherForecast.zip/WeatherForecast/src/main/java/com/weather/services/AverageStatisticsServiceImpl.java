package com.weather.services;

import com.weather.model.AverageStats;
import com.weather.model.DailyAverage;
import com.weather.model.NightlyAverage;
import com.weather.model.PressureAverage;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.List;

@Service
public class AverageStatisticsServiceImpl implements AverageStatisticsService{

    @Override
    public AverageStats calculateAverageDaily(List<Double> dailyTemps, AverageStats averageStats) {
        Double total = 0.0;
        for(Double tmp : dailyTemps)
            total+=tmp;
        Double avgDailyTmp = total/dailyTemps.size();
        DailyAverage dailyAverage = new DailyAverage(round(avgDailyTmp),"Celsius");
        averageStats.setDailyAverage(dailyAverage);
        return averageStats;
    }

    @Override
    public AverageStats calculateAverageNightly(List<Double> nightlyTemps, AverageStats averageStats) {
        Double total = 0.0;
        for(Double tmp : nightlyTemps)
            total+=tmp;
        Double avgNightlyTmp = total/nightlyTemps.size();
        NightlyAverage nightlyAverage = new NightlyAverage(round(avgNightlyTmp),"Celsius");
        averageStats.setNightlyAverage(nightlyAverage);
        return averageStats;
    }

    @Override
    public AverageStats calculateAveragePressure(List<Double> pressureData, AverageStats averageStats) {
        Double total = 0.0;
        for(Double pressure : pressureData)
            total+=pressure;
        Double avgPressure = total/pressureData.size();
        PressureAverage pressureAverage = new PressureAverage(round(avgPressure),"hPa");
        averageStats.setPressureAverage(pressureAverage);
        return averageStats;
    }

    private Double round(Double d){
        BigDecimal bigDecimal = BigDecimal.valueOf(d);
        bigDecimal = bigDecimal.setScale(2, RoundingMode.HALF_UP);
        return bigDecimal.doubleValue();
    }

}
