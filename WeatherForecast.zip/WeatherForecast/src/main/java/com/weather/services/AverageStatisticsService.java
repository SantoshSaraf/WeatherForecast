package com.weather.services;

import com.weather.model.AverageStats;

import java.util.List;


public interface AverageStatisticsService {

    AverageStats calculateAverageDaily(List<Double> dailyTemps, AverageStats averageStats);
    AverageStats calculateAverageNightly(List<Double> nightlyTemps, AverageStats averageStats);
    AverageStats calculateAveragePressure(List<Double> pressureData, AverageStats averageStats);

}
