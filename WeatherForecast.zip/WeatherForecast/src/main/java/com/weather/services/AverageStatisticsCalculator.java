package com.weather.services;

import com.weather.model.AverageStats;
import com.weather.model.ForecastDetail;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
public class AverageStatisticsCalculator {

    @Autowired
    AverageStatisticsService averageStatisticsService;

    public AverageStats averageStatisticsCalculator(List<ForecastDetail> forecastDetails, AverageStats averageStats){
        List<Double> dailyTemps = new ArrayList<>();
        List<Double> nightlyTemps = new ArrayList<>();
        List<Double> pressureData = new ArrayList<>();
        get_3DaysData(forecastDetails, averageStats, dailyTemps, nightlyTemps, pressureData);
        averageStatisticsService.calculateAverageDaily(dailyTemps,averageStats);
        averageStatisticsService.calculateAverageNightly(nightlyTemps,averageStats);
        averageStatisticsService.calculateAveragePressure(pressureData,averageStats);
        return averageStats;
    }

    private void get_3DaysData(List<ForecastDetail> forecastDetails,  AverageStats averageStats,List<Double> dailyTemps, List<Double> nightlyTemps, List<Double> pressureData) {
        int day=1;
        averageStats.setStartDateTime(forecastDetails.get(0).getDt_txt());
        for(ForecastDetail forecastDetail: forecastDetails){
            if(day>3) {
                averageStats.setEndDateTime(forecastDetail.getDt_txt());
                break;
            }
            int hour = forecastDetail.getDt_txt().getHour();
            if(hour >= 6 && hour < 18)
                dailyTemps.add(forecastDetail.getMain().getTemp());
            else if(hour == 3){
                nightlyTemps.add(forecastDetail.getMain().getTemp());
                day++;
            }else
                nightlyTemps.add(forecastDetail.getMain().getTemp());
            pressureData.add(forecastDetail.getMain().getPressure());
        }
    }

}
