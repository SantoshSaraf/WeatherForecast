package com.weather.services;

import com.weather.exception.OpenWeatherMapException;
import com.weather.model.ForecastDetail;

import java.util.List;
import java.util.Map;

public interface OpenWeatherMapService {
    List<ForecastDetail> getOpenWeatherForecastData(String city) throws OpenWeatherMapException;
    Map<String,String> getUriParams(String city);
}
